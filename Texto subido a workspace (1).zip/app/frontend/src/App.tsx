import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Index from './pages/Index';
import Store from './pages/Store';
import TacticalDrop from './pages/TacticalDrop';
import CategoryPage from './pages/CategoryPage';
import ProductDetail from './pages/ProductDetail';
// MODULE_IMPORTS_START
// MODULE_IMPORTS_END

const queryClient = new QueryClient();

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Index />} />
    <Route path="/store" element={<Store />} />
    <Route path="/tactical" element={<TacticalDrop />} />
    <Route path="/category/:categorySlug" element={<CategoryPage />} />
    <Route path="/category/:categorySlug/product/:productId" element={<ProductDetail />} />
    <Route path="/category/:categorySlug/:subcategorySlug" element={<CategoryPage />} />
    {/* MODULE_ROUTES_START */}
    {/* MODULE_ROUTES_END */}
  </Routes>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    {/* MODULE_PROVIDERS_START */}
    {/* MODULE_PROVIDERS_END */}
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </TooltipProvider>
    {/* MODULE_PROVIDERS_CLOSE */}
  </QueryClientProvider>
);

export default App;
export { AppRoutes };