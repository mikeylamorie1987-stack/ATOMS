export interface Product {
  id: string;
  name: string;
  image: string;
  images?: string[];
  price: string;
  description: string;
  sizes?: string[];
  colors?: { name: string; hex: string }[];
  details?: string[];
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
}

export interface CategoryContent {
  headline: string;
  shortOfIt: string;
  theWhy: string;
  whatsInside: string[];
  cta: string;
  ctaLink?: string;
}

export interface CategoryData {
  id: string;
  slug: string;
  name: string;
  heroImage: string;
  heroVideo?: string;
  subcategories: Subcategory[];
  content: CategoryContent;
  products: Product[];
}

// Default sizes and colors for all products
const defaultSizes = ['XS', 'S', 'M', 'L', 'XL', '2XL'];
const defaultColors: { name: string; hex: string }[] = [
  { name: 'Blackout', hex: '#0a0a0a' },
  { name: 'Charred', hex: '#2d2d2d' },
  { name: 'Blood Red', hex: '#8B0000' },
  { name: 'Ash', hex: '#4a4a4a' },
];

// ===== MEN =====
const menProducts: Product[] = [
  { id: 'men-1', name: 'WARPATH HENLEY', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', images: ['https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png'], price: '$68.00', description: 'Heavyweight cotton henley built for the frontline. Cut from 320gsm brushed cotton with reinforced button placket and raw-edge seams. This isn\'t your grandfather\'s henley — it\'s armor disguised as comfort.', sizes: defaultSizes, colors: defaultColors, details: ['320gsm heavyweight brushed cotton', 'Reinforced 3-button placket', 'Raw-edge seams throughout', 'Drop shoulder relaxed fit', 'Garment-dyed for lived-in feel', 'Made in USA'] },
  { id: 'men-2', name: 'IRON DOCTRINE TEE', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', images: ['https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png'], price: '$48.00', description: 'Statement tee. No compromise. Premium ringspun cotton with discharge print that becomes part of the fabric. Wears harder the more you wash it.', sizes: defaultSizes, colors: defaultColors, details: ['250gsm ringspun cotton', 'Discharge printed graphics', 'Ribbed collar won\'t stretch', 'Side-seamed construction', 'Pre-shrunk'] },
  { id: 'men-3', name: 'SCORCHED EARTH FLANNEL', image: 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', images: ['https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png'], price: '$98.00', description: 'Rugged flannel with a burnt-out wash. Double-brushed for softness, enzyme-washed for that scorched look. Two chest pockets. Built for layering over your convictions.', sizes: defaultSizes, colors: [{ name: 'Scorched Black', hex: '#1a1a1a' }, { name: 'Ember Red', hex: '#5c1010' }, { name: 'Smoke', hex: '#3d3d3d' }], details: ['Double-brushed cotton flannel', 'Enzyme-washed finish', 'Dual chest pockets with button closure', 'Curved hem', 'Relaxed fit through body'] },
  { id: 'men-4', name: 'GHOST PROTOCOL HOODIE', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', images: ['https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png'], price: '$128.00', description: 'Oversized heavyweight hoodie. Disappear in plain sight. 450gsm French terry with double-layered hood, kangaroo pocket, and thumbhole cuffs. The kind of hoodie that makes people cross the street.', sizes: defaultSizes, colors: defaultColors, details: ['450gsm French terry', 'Double-layered hood', 'Kangaroo pocket with hidden zip', 'Thumbhole cuffs', 'Oversized boxy fit', 'YKK hardware'] },
  { id: 'men-5', name: 'DOOMED OPS CARGO', image: 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', images: ['https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png'], price: '$148.00', description: 'Tactical cargo pants with reinforced knees. Ripstop cotton with 8 pockets, articulated knees, and adjustable ankle cuffs. Carry everything. Fear nothing.', sizes: ['28', '30', '32', '34', '36', '38'], colors: [{ name: 'Blackout', hex: '#0a0a0a' }, { name: 'OD Green', hex: '#2d3a2d' }, { name: 'Coyote', hex: '#4a3f2f' }], details: ['Ripstop cotton blend', '8 utility pockets', 'Reinforced articulated knees', 'Adjustable ankle cuffs', 'Gusseted crotch for mobility', 'Triple-stitched stress points'] },
  { id: 'men-6', name: 'NIGHT RAID BOMBER', image: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', images: ['https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png'], price: '$198.00', description: 'Nylon shell bomber. Built for the dark hours. Water-resistant nylon shell with quilted lining, ribbed collar/cuffs/hem, and interior stash pocket. Moves silent. Hits hard.', sizes: defaultSizes, colors: [{ name: 'Midnight', hex: '#0d0d1a' }, { name: 'Blackout', hex: '#0a0a0a' }, { name: 'Blood', hex: '#4a0000' }], details: ['Water-resistant nylon shell', 'Quilted insulated lining', 'Ribbed collar, cuffs & hem', 'Interior stash pocket', 'YKK zip with branded pull', 'Slim-athletic fit'] },
];

// ===== WOMEN =====
const womenProducts: Product[] = [
  { id: 'women-1', name: 'LIBERTY CROP TEE', image: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', price: '$52.00', description: 'Cropped tee with raw edge hem. Fierce and free.' },
  { id: 'women-2', name: 'GRACE & GRIT TANK', image: 'https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png', price: '$44.00', description: 'Relaxed fit tank. Soft fabric, hard message.' },
  { id: 'women-3', name: 'WILDHEART HOODIE', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', price: '$118.00', description: 'Oversized pullover with distressed details.' },
  { id: 'women-4', name: 'REBEL DAUGHTER JOGGER', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$88.00', description: 'Tapered jogger with bold side graphics.' },
  { id: 'women-5', name: 'IRON MAIDEN JACKET', image: 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', price: '$168.00', description: 'Moto-inspired jacket. Armored femininity.' },
  { id: 'women-6', name: 'DEFIANT DRESS', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', price: '$78.00', description: 'T-shirt dress with raw edge and bold print.' },
];

// ===== FAITH =====
const faithProducts: Product[] = [
  { id: 'faith-1', name: 'BLOOD BOUGHT TEE', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', price: '$48.00', description: 'Heavyweight tee. Paid in full.' },
  { id: 'faith-2', name: 'ARMOR BEARER HOODIE', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$128.00', description: 'Full armor. Full faith. Full send.' },
  { id: 'faith-3', name: 'HOUSE STANDARD FLAG TEE', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', price: '$52.00', description: 'Plant the flag. Hold the line.' },
  { id: 'faith-4', name: 'PSALM 91 LONG SLEEVE', image: 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', price: '$58.00', description: 'Under His wings. Long sleeve comfort.' },
  { id: 'faith-5', name: 'COVENANT CARGO SHORT', image: 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', price: '$78.00', description: 'Tactical cargo short with faith-forward details.' },
  { id: 'faith-6', name: 'REDEEMED BOMBER', image: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', price: '$188.00', description: 'Bomber jacket with cross-stitch back panel.' },
];

// ===== KIDS =====
const kidsProducts: Product[] = [
  { id: 'kids-1', name: 'REBEL RUNT TEE (BOYS)', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$32.00', description: 'Mini warrior. Maximum attitude.' },
  { id: 'kids-2', name: 'REBEL RUNT TEE (GIRLS)', image: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', price: '$32.00', description: 'Fierce from the start.' },
  { id: 'kids-3', name: 'LITTLE LION HOODIE', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', price: '$58.00', description: 'Cozy hoodie for the pride.' },
  { id: 'kids-4', name: 'TINY WARRIOR JOGGER', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', price: '$44.00', description: 'Comfortable joggers built for play and war.' },
  { id: 'kids-5', name: 'RUNTCHKIN BOMBER', image: 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', price: '$78.00', description: 'Scaled-down bomber. Full-size attitude.' },
  { id: 'kids-6', name: 'CUB PACK TEE SET', image: 'https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png', price: '$52.00', description: '3-pack tees for the young pack.' },
];

// ===== LIFESTYLE/HOME =====
const lifestyleProducts: Product[] = [
  { id: 'life-1', name: 'HEARTH CANDLE SET', image: 'https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png', price: '$44.00', description: 'Soy wax candles. Gunpowder & cedar scent.' },
  { id: 'life-2', name: 'HOMEFRONT THROW', image: 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', price: '$88.00', description: 'Woven throw blanket with tactical pattern.' },
  { id: 'life-3', name: 'HUNTER\'S CREED MUG', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$28.00', description: 'Ceramic mug. Black. Bold. Unbreakable spirit.' },
  { id: 'life-4', name: 'CONCRETE REMNANT POSTER', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', price: '$38.00', description: 'Gallery-quality print on heavyweight stock.' },
  { id: 'life-5', name: 'FIELD JOURNAL', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', price: '$24.00', description: 'Leather-bound journal. Document the mission.' },
  { id: 'life-6', name: 'BUNKER FLASK', image: 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', price: '$34.00', description: 'Insulated flask. Matte black. Indestructible.' },
];

export const categories: CategoryData[] = [
  {
    id: 'men',
    slug: 'men',
    name: 'MEN',
    heroImage: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png',
    subcategories: [
      { id: 'battleborn', name: 'BATTLEBORN', slug: 'battleborn' },
      { id: 'burn-barrel', name: 'BURN BARREL', slug: 'burn-barrel' },
      { id: 'division-doom', name: 'DIVISION DOOM', slug: 'division-doom' },
    ],
    content: {
      headline: 'BUILT FOR THE BATTLEFIELD',
      shortOfIt: 'This isn\'t fashion. It\'s armor for the man who refuses to kneel. Every thread is a declaration — you were born to fight, built to endure, and dressed to dominate.',
      theWhy: 'Because the world needs men who look like they mean it. Because your wardrobe should hit as hard as your convictions. Because settling for soft is not in your DNA.',
      whatsInside: [
        'Heavyweight cotton & reinforced stitching',
        'Tactical cuts designed for movement',
        'Dark, rugged colorways — no pastels, no apologies',
        'Graphics that speak louder than words',
        'Limited drops — once they\'re gone, they\'re gone',
      ],
      cta: 'GEAR UP NOW',
    },
    products: menProducts,
  },
  {
    id: 'women',
    slug: 'women',
    name: 'WOMEN',
    heroImage: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png',
    subcategories: [
      { id: 'liberty-daughters', name: 'LIBERTY DAUGHTERS', slug: 'liberty-daughters' },
      { id: 'grace-and-grit', name: 'GRACE & GRIT', slug: 'grace-and-grit' },
      { id: 'wildheart', name: 'WILDHEART', slug: 'wildheart' },
    ],
    content: {
      headline: 'FORGED IN FIRE. DRESSED IN DEFIANCE.',
      shortOfIt: 'For the woman who doesn\'t ask permission. Bold silhouettes, raw edges, and graphics that refuse to whisper. This is streetwear for daughters of rebellion.',
      theWhy: 'Because strength isn\'t soft. Because you can be fierce and feminine on your own terms. Because the world needs women who dress like they\'re ready for war.',
      whatsInside: [
        'Relaxed & oversized fits with edge',
        'Distressed details & raw hems',
        'Dark neutrals with bold accent graphics',
        'Pieces that layer hard and stand alone',
        'Unapologetic messaging on every piece',
      ],
      cta: 'CLAIM YOUR ARMOR',
    },
    products: womenProducts,
  },
  {
    id: 'faith',
    slug: 'faith',
    name: 'FAITH',
    heroImage: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png',
    subcategories: [
      { id: 'blood-bought', name: 'BLOOD BOUGHT', slug: 'blood-bought' },
      { id: 'armor-bearer', name: 'ARMOR BEARER', slug: 'armor-bearer' },
      { id: 'house-standard', name: 'HOUSE STANDARD', slug: 'house-standard' },
    ],
    content: {
      headline: 'WEAR YOUR CONVICTION',
      shortOfIt: 'Faith isn\'t quiet. It\'s a war cry. These pieces are for the ones who carry their belief like a weapon — visible, unyielding, and unashamed.',
      theWhy: 'Because your faith deserves more than a bumper sticker. Because the armor of God looks good in heavyweight cotton. Because the world needs to see who you serve.',
      whatsInside: [
        'Scripture-inspired graphics with raw edge',
        'Cross & shield motifs — no generic church merch',
        'Heavyweight fabrics that endure',
        'Dark, reverent colorways',
        'Pieces that start conversations and convictions',
      ],
      cta: 'STAND YOUR GROUND',
    },
    products: faithProducts,
  },
  {
    id: 'kids',
    slug: 'kids',
    name: 'KIDS',
    heroImage: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png',
    subcategories: [
      { id: 'rebel-runtchkins-boys', name: 'REBEL RUNTCHKINS BOYS', slug: 'rebel-runtchkins-boys' },
      { id: 'rebel-runtchkins-girls', name: 'REBEL RUNTCHKINS GIRLS', slug: 'rebel-runtchkins-girls' },
      { id: 'little-lions', name: 'LITTLE LIONS', slug: 'little-lions' },
    ],
    content: {
      headline: 'RAISE THEM WILD',
      shortOfIt: 'Mini warriors deserve real gear. Not cartoon nonsense — real streetwear scaled down for the next generation of rebels. Bold. Tough. Built for play and war.',
      theWhy: 'Because your kids are watching. Because they deserve clothes that match the fire you\'re raising them with. Because soft parenting makes soft kids — and that\'s not what we\'re building here.',
      whatsInside: [
        'Durable fabrics that survive the battlefield (playground)',
        'Bold graphics — no cartoon animals',
        'Matching family sets available',
        'Comfortable fits for active warriors',
        'Ages 2-12 covered',
      ],
      cta: 'OUTFIT THE PACK',
    },
    products: kidsProducts,
  },
  {
    id: 'lifestyle',
    slug: 'lifestyle',
    name: 'LIFESTYLE / HOME',
    heroImage: 'https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png',
    subcategories: [
      { id: 'hearth-homefront', name: 'HEARTH & HOMEFRONT', slug: 'hearth-homefront' },
      { id: 'hunters-creed', name: "HUNTER'S CREED", slug: 'hunters-creed' },
      { id: 'concrete-remnant', name: 'CONCRETE REMNANT', slug: 'concrete-remnant' },
    ],
    content: {
      headline: 'YOUR SPACE. YOUR RULES.',
      shortOfIt: 'The rebellion doesn\'t stop at your wardrobe. Your home, your desk, your morning coffee — everything should carry the same weight. Dark. Intentional. Unapologetically yours.',
      theWhy: 'Because your space is an extension of your identity. Because mass-produced home goods are soulless. Because even your coffee mug should have a backbone.',
      whatsInside: [
        'Hand-poured candles with rugged scents',
        'Tactical-inspired home textiles',
        'Matte black drinkware & accessories',
        'Gallery-quality art prints',
        'Leather-bound journals & field gear',
      ],
      cta: 'FORTIFY YOUR SPACE',
    },
    products: lifestyleProducts,
  },
];

export function getCategoryBySlug(slug: string): CategoryData | undefined {
  return categories.find((c) => c.slug === slug);
}

export function getProductById(categorySlug: string, productId: string): Product | undefined {
  const category = getCategoryBySlug(categorySlug);
  if (!category) return undefined;
  return category.products.find((p) => p.id === productId);
}

export function getSubcategoryProducts(categorySlug: string, subcategorySlug: string): Product[] {
  const category = getCategoryBySlug(categorySlug);
  if (!category) return [];
  // For demo, split products across subcategories
  const subIndex = category.subcategories.findIndex((s) => s.slug === subcategorySlug);
  if (subIndex === -1) return category.products;
  const perSub = Math.ceil(category.products.length / category.subcategories.length);
  return category.products.slice(subIndex * perSub, (subIndex + 1) * perSub);
}