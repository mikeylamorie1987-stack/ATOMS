import React, { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Image } from '@/components/ui/image';
import { ArrowRight, Shield, Flame, Star, Crosshair, Zap } from 'lucide-react';
import CollectionShowcase from '@/components/CollectionShowcase';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// --- Utility Components ---

const Reveal = ({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(element);
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${className || ''} ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

const ParallaxImage = ({ src, alt, className }: { src: string; alt: string; className?: string; speed?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  return (
    <div ref={ref} className={`overflow-hidden ${className}`}>
      <motion.div style={{ y }} className="w-full h-[120%] -mt-[10%]">
        <Image src={src} alt={alt} className="w-full h-full object-cover" />
      </motion.div>
    </div>
  );
};

const Marquee = () => {
  return (
    <div className="relative flex overflow-hidden py-4 bg-primary text-background border-y border-background/10">
      <motion.div
        className="flex whitespace-nowrap font-heading font-black text-4xl md:text-6xl uppercase tracking-tighter"
        animate={{ x: [0, -1000] }}
        transition={{ repeat: Infinity, ease: "linear", duration: 20 }}
      >
        {[...Array(8)].map((_, i) => (
          <span key={i} className="mx-8 flex items-center gap-4 text-surface-dark">
            RAW// DEFIANT// AMERICA-FIRST <Star className="w-8 h-8 fill-current" />
          </span>
        ))}
      </motion.div>
    </div>
  );
};

const GlitchText = ({ text, className }: { text: string; className?: string }) => {
  return (
    <div className={`relative inline-block group ${className}`}>
      <span className="relative z-10 text-silver-metallic text-4xl italic underline">& {text}</span>
      <span className="absolute top-0 left-0 -z-10 w-full h-full text-primary opacity-0 group-hover:opacity-70 group-hover:translate-x-[2px] transition-all duration-100 select-none">
        & {text}
      </span>
      <span className="absolute top-0 left-0 -z-10 w-full h-full text-secondary opacity-0 group-hover:opacity-70 group-hover:-translate-x-[2px] transition-all duration-100 select-none">
        & {text}
      </span>
    </div>
  );
};

// --- Main Page Component ---

export default function HomePage() {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={containerRef} className="w-full bg-background text-foreground overflow-clip selection:bg-primary selection:text-white">
      <style>{`
        .clip-diagonal {
          clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
        }
        .clip-chevron {
          clip-path: polygon(0 0, 100% 0, 85% 100%, 15% 100%);
        }
        .grain-overlay {
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.05'/%3E%3C/svg%3E");
        }
        .text-stroke {
          -webkit-text-stroke: 1px rgba(255, 255, 255, 0.2);
          color: transparent;
        }
        .text-stroke-hover:hover {
          -webkit-text-stroke: 0px;
          color: #FF0000;
        }
      `}</style>

      {/* Global Grain Overlay */}
      <div className="fixed inset-0 pointer-events-none z-10 grain-overlay mix-blend-overlay opacity-10"></div>

      {/* Header */}
      <Header />

      {/* --- HERO SECTION --- */}
      <section className="relative w-full h-screen min-h-[800px] flex flex-col justify-center items-center overflow-hidden">
        {/* Background Layers */}
        <div className="absolute inset-0 z-0">
          <ParallaxImage
            src="https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png?originWidth=1600&originHeight=896"
            alt="Distressed American Flag Texture"
            className="w-full h-full opacity-60 grayscale contrast-125"
            speed={0.3}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-transparent via-background/60 to-background"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 w-full mx-auto px-4 md:px-16 lg:px-32 flex flex-col items-center text-center">
          <Reveal>
            <div className="flex items-center justify-center gap-4 mb-6 text-secondary font-paragraph text-sm tracking-[0.3em] uppercase">
              <span className="w-12 h-[1px] bg-secondary"></span>
              <span className="text-silver-metallic">Est. 2024 // USA</span>
              <span className="w-12 h-[1px] bg-secondary"></span>
            </div>
          </Reveal>

          <div className="relative mb-8">
            <motion.h1
              className="font-heading text-[12vw] md:text-[6.5vw] leading-[0.8] font-black text-foreground uppercase tracking-tighter"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              NOBLE
              <br />
              <span className="text-transparent text-stroke relative">
                ANARCHY
                <motion.span
                  className="absolute inset-0 text-primary opacity-0"
                  animate={{ opacity: [0, 0.5, 0, 0.2, 0] }}
                  transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }}
                >
                  ANARCHY
                </motion.span>
              </span>
              <br />
              <span className="bg-gradient-to-r from-[#B87333] to-[#A96424] bg-clip-text text-[#873f1eff]">
                COLLECTIVE
              </span>
            </motion.h1>
          </div>

          <Reveal delay={200}>
            <p className="font-paragraph text-lg md:text-xl text-silver-metallic max-w-2xl mx-auto mb-12 leading-relaxed">
              Built for the unbroken. Every stitch is a middle finger to mediocrity — forged for the ones who refuse to kneel, comply, or fade quietly into the background.
            </p>
          </Reveal>

          <Reveal delay={400}>
            <Link to="/store" className="group relative inline-flex items-center justify-center px-12 py-6 overflow-hidden font-bold text-white uppercase tracking-widest transition-all duration-300 bg-transparent hover:border-primary hover:text-primary font-heading border-[1.6px] border-dotted border-[#ff0000] rounded-[41px]">
              <span className="absolute w-0 h-0 transition-all duration-500 ease-out bg-white rounded-full group-hover:w-56 group-hover:h-56 opacity-10"></span>
              <span className="relative flex items-center gap-3">
                Shop Collection <ArrowRight className="w-5 h-5" />
              </span>
            </Link>
          </Reveal>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-silver-metallic/50"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="text-[10px] uppercase tracking-widest font-paragraph">Scroll to Explore</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-silver-metallic/50 to-transparent"></div>
        </motion.div>
      </section>

      {/* --- TICKER SECTION --- */}
      <section className="w-full bg-primary py-2 z-20 relative transform -rotate-1 scale-105 origin-left border-y-4 border-black">
        <Marquee />
      </section>

      {/* --- MANIFESTO / VALUES SECTION --- */}
      <section className="relative w-full py-32 bg-background">
        <div className="max-w-[120rem] mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Sticky Title */}
            <div className="lg:col-span-5 relative">
              <div className="sticky top-32">
                <h2 className="text-6xl md:text-8xl font-black mb-8 text-left normal-case text-foreground font-cinzel">OUR MISSION</h2>
                <div className="w-24 h-2 bg-primary mb-8"></div>
                <p className="font-paragraph text-silver-metallic text-lg max-w-md mb-12">
                  This isn't a clothing line — it's a uniform for the unapologetic. Threaded with grit, stitched with conviction, and built to outlast the cowards who tried to silence us.
                </p>
                <Link to="/mission" className="hidden lg:inline-flex items-center gap-2 text-primary font-heading font-bold uppercase tracking-widest hover:text-white transition-colors">
                  <Crosshair className="w-5 h-5" />
                  View Mission
                </Link>
              </div>
            </div>

            {/* Scrolling Cards */}
            <div className="lg:col-span-7 space-y-24 pt-12 lg:pt-0">
              {/* Card 1 */}
              <Reveal className="group">
                <div className="relative border-l-2 border-silver-metallic/20 pl-8 md:pl-12 py-4 transition-all duration-500 hover:border-primary">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 bg-background border-2 border-silver-metallic/20 group-hover:border-primary transition-colors text-primary"></div>
                  <Shield className="w-16 h-16 text-silver-metallic mb-6 group-hover:text-primary transition-colors duration-300" />
                  <h3 className="font-heading text-4xl md:text-5xl font-bold text-foreground uppercase mb-4">
                    <GlitchText text="UNAPOLOGETICALLY RAW" />
                  </h3>
                  <p className="font-paragraph text-silver-metallic/80 text-lg leading-relaxed max-w-xl">
                    No filters. No flinch. No permission slips. We wear our convictions like armor — heavy, honest, and impossible to apologize away.
                  </p>
                </div>
              </Reveal>

              {/* Card 2 */}
              <Reveal className="group">
                <div className="relative border-l-2 border-silver-metallic/20 pl-8 md:pl-12 py-4 transition-all duration-500 hover:border-destructive">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 bg-background border-2 border-silver-metallic/20 group-hover:border-destructive transition-colors"></div>
                  <Flame className="w-16 h-16 text-silver-metallic mb-6 group-hover:text-destructive transition-colors duration-300" />
                  <h3 className="font-heading text-4xl md:text-5xl font-bold text-foreground uppercase mb-4">
                    <GlitchText text="CONCRETELY DEFIANT" />
                  </h3>
                  <p className="font-paragraph text-silver-metallic/80 text-lg leading-relaxed max-w-xl">
                    Every graphic hits like a hammer. Hand-distressed, blue-collar, cinematic — built to make the comfortable uncomfortable and the loud go quiet.
                  </p>
                </div>
              </Reveal>

              {/* Card 3 */}
              <Reveal className="group">
                <div className="relative border-l-2 border-silver-metallic/20 pl-8 md:pl-12 py-4 transition-all duration-500 hover:border-secondary">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 bg-background border-2 border-silver-metallic/20 group-hover:border-secondary transition-colors"></div>
                  <Star className="w-16 h-16 text-silver-metallic mb-6 group-hover:text-secondary transition-colors duration-300" />
                  <h3 className="font-heading text-4xl md:text-5xl font-bold text-foreground uppercase mb-4">
                    <GlitchText text="ALWAYS AMERICA FIRST" />
                  </h3>
                  <p className="font-paragraph text-silver-metallic/80 text-lg leading-relaxed max-w-xl">
                    Weathered, battle-tested, and stitched in the colors of a country worth defending. Wear it like a flag in a war zone — because that's exactly what it is.
                  </p>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* --- FEATURED COLLECTION (Editorial Split) --- */}
      <section className="relative w-full min-h-screen flex flex-col lg:flex-row bg-[#0a0a0a]">
        {/* Content Side */}
        <div className="w-full lg:w-1/2 relative flex flex-col justify-center p-8 md:p-20 lg:p-32 border-l border-white/5">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent lg:hidden"></div>

          <Reveal>
            <h2 className="font-heading text-6xl lg:text-6xl font-black uppercase text-[#FF0000D9] text-left">
              STREET<br />
              <span className="text-stroke text-7xl">WEAR</span><br />
              REDEFINED
            </h2>
          </Reveal>

          <Reveal delay={200}>
            <div className="flex flex-wrap gap-4 mb-8 mt-8">
              <div className="border border-white/20 rounded-full text-xs font-paragraph uppercase text-silver-metallic py-3 px-5">100% Cotton - PREMIUM</div>
              <div className="border border-white/20 rounded-full text-xs font-paragraph uppercase text-silver-metallic py-3 px-5">Distressed Finishes</div>
              <div className="border border-white/20 rounded-full text-xs font-paragraph uppercase text-silver-metallic py-3 px-5">DESIGNED ON THE HOMEFRONT</div>
            </div>
          </Reveal>

          <Reveal delay={300}>
            <p className="text-silver-metallic text-lg leading-relaxed mb-12 max-w-xl font-paragraph">
              Heavyweight streetwear with a working-man's soul. Premium cotton, distressed finishes, and designs that refuse to be ignored.
            </p>
          </Reveal>

          <Reveal delay={400}>
            <div className="flex flex-col sm:flex-row gap-6">
              <Link to="/store" className="bg-primary text-white font-bold uppercase px-10 py-4 hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 font-heading">
                Shop The Drop <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/store" className="border border-white/30 text-white font-heading font-bold uppercase px-10 py-4 hover:bg-white hover:text-black transition-colors flex items-center justify-center">
                View Lookbook
              </Link>
            </div>
          </Reveal>
        </div>

        {/* Image Side */}
        <div className="w-full lg:w-1/2 h-[60vh] lg:h-auto relative overflow-hidden group">
          <div className="absolute inset-0 bg-primary/10 mix-blend-overlay z-10 pointer-events-none"></div>
          <Image
            src="https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png"
            alt="Featured streetwear collection"
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 grayscale hover:grayscale-0 opacity-[0.79]"
            originWidth={1023}
            originHeight={1537}
            focalPointX={47.47}
            focalPointY={47.11}
          />

          {/* Floating Badge */}
          <div className="absolute bottom-8 left-8 z-20 bg-background/90 backdrop-blur-sm border border-white/10 p-6 max-w-xs">
            <div className="flex items-center gap-2 text-primary mb-2">
              <Zap className="w-4 h-4 fill-current" />
              <span className="text-xs uppercase tracking-widest font-paragraph">NEW LINE & PREMIUM DROP</span>
            </div>
            <p className="text-white uppercase font-cinzel text-2xl">BLACK OUT DOCTRINE</p>
          </div>
        </div>
      </section>

      {/* --- VISUAL BREATHER --- */}
      <section className="relative w-full h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <ParallaxImage
            src="https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png?originWidth=1600&originHeight=768"
            alt="Weathered metal texture background"
            className="w-full h-full object-cover opacity-40"
            speed={0.2}
          />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
          <Reveal>
            <blockquote className="text-3xl md:text-5xl lg:text-5xl font-bold text-white uppercase leading-tight font-paragraph">
              "Stay loud. Stay armed. Stay unapologetic — the world was never built by the polite."
            </blockquote>
            <cite className="block mt-8 font-paragraph text-primary text-lg md:text-xl not-italic tracking-widest">
              — Noble Anarchy Collective
            </cite>
          </Reveal>
        </div>
      </section>

      {/* --- COLLECTION SHOWCASES --- */}
      <CollectionShowcase
        collectionId="MensWearAndAccessories"
        collectionName="BATTLEBORN DIVISION"
        collectionDescription="Tactical streetwear engineered for the modern warrior. Precision-cut, battle-tested, and built for those who refuse to compromise."
        features={[
          "Premium heavyweight cotton blend",
          "Distressed tactical detailing",
          "Reinforced seams for durability",
          "Designed for the uncompromising"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png"
        primaryCTA="SHOP COLLECTION"
        secondaryCTA="VIEW LOOKBOOK"
      />
      <CollectionShowcase
        collectionId="AsphaltStreetwear"
        collectionName="ASPHALT STREETWEAR"
        collectionDescription="Urban rebellion meets concrete aesthetics. Raw, unfiltered, and designed for the streets that built you."
        features={[
          "100% authentic street style",
          "Hand-distressed finishes",
          "Limited edition drops",
          "Built for the bold"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png"
        primaryCTA="EXPLORE COLLECTION"
      />
      <CollectionShowcase
        collectionId="BloodBought"
        collectionName="BLOOD BOUGHT"
        collectionDescription="For the faithful. For the fierce. For those who bleed conviction. Every piece carries the weight of purpose."
        features={[
          "Faith-driven design",
          "Premium construction",
          "Symbolic graphics",
          "Worn with conviction"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png"
        primaryCTA="SHOP NOW"
      />
      <CollectionShowcase
        collectionId="BurnBarrel"
        collectionName="BURN BARREL"
        collectionDescription="Scorched. Scarred. Surviving. This is the collection for those who've been through the fire and came out stronger."
        features={[
          "Distressed heritage design",
          "Weathered finishes",
          "Survivor's aesthetic",
          "Built to last"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png"
        primaryCTA="VIEW COLLECTION"
      />
      <CollectionShowcase
        collectionId="CradleRemnant"
        collectionName="CRADLE REMNANT"
        collectionDescription="Heritage meets rebellion. Rooted in tradition, designed for the future. Wear your legacy."
        features={[
          "Heritage-inspired graphics",
          "Premium fabric blend",
          "Timeless design",
          "Built for generations"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png"
        primaryCTA="SHOP HERITAGE"
      />
      <CollectionShowcase
        collectionId="EvesRebellion"
        collectionName="EVE'S REBELLION"
        collectionDescription="Unapologetically fierce. Uncompromisingly bold. For women who refuse to fade into the background."
        features={[
          "Designed for women warriors",
          "Empowering graphics",
          "Premium fit and comfort",
          "Defiant by design"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png"
        primaryCTA="DISCOVER COLLECTION"
      />
      <CollectionShowcase
        collectionId="HearthAndHomefront"
        collectionName="HEARTH AND HOMEFRONT"
        collectionDescription="Where comfort meets conviction. Designed for those who stand their ground and defend what matters."
        features={[
          "Comfort-first construction",
          "Homefront aesthetic",
          "Durable everyday wear",
          "Built for defenders"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png"
        primaryCTA="SHOP COMFORT"
      />
      <CollectionShowcase
        collectionId="HuntersCreed"
        collectionName="HUNTER'S CREED"
        collectionDescription="For the hunters. For the trackers. For those who pursue their vision with relentless determination."
        features={[
          "Tactical hunter aesthetic",
          "Precision-engineered fit",
          "Rugged durability",
          "Built for the pursuit"
        ]}
        mediaImage1="https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png"
        mediaImage2="https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png"
        primaryCTA="HUNT WITH US"
      />

      {/* --- CTA SECTION --- */}
      <section className="w-full py-32 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>

        <div className="max-w-[100rem] mx-auto px-4 md:px-8 text-center relative z-10">
          <Reveal>
            <h2 className="font-heading text-6xl md:text-8xl lg:text-9xl font-black text-white uppercase tracking-tighter mb-8">
              WEAR YOUR<br />PRIDE
            </h2>
          </Reveal>

          <Reveal delay={200}>
            <p className="font-paragraph text-xl md:text-2xl text-white/90 uppercase tracking-widest mb-12 max-w-3xl mx-auto">
              Join the movement. Stand out. Make a statement.
            </p>
          </Reveal>

          <Reveal delay={400}>
            <Link
              to="/store"
              className="clip-chevron inline-flex items-center gap-4 bg-black text-white font-heading text-xl font-bold uppercase px-12 py-6 hover:bg-white hover:text-black transition-all duration-300"
            >
              Start Shopping
              <ArrowRight className="w-6 h-6" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}