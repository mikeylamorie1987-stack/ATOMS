import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { categories } from '@/data/categories';

export default function StorePage() {
  return (
    <div className="w-full min-h-screen bg-[#0a0a0a] text-white selection:bg-red-600 selection:text-white">
      <Header />

      {/* Hero */}
      <section className="pt-32 pb-16 px-4 md:px-12 max-w-[120rem] mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-gray-500 hover:text-red-500 transition-colors font-mono text-xs uppercase tracking-widest mb-8">
          <ArrowLeft className="w-3 h-3" /> Back to Home
        </Link>
        <h1 className="font-heading text-5xl md:text-7xl font-black uppercase tracking-tighter text-white mb-4">
          THE STORE
        </h1>
        <p className="text-gray-400 text-lg max-w-2xl">
          Browse our collections. Each piece is a statement — designed for the bold, built for the defiant.
        </p>
      </section>

      {/* Categories Grid */}
      <section className="px-4 md:px-12 pb-32 max-w-[120rem] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {categories.map((category) => (
            <Link
              key={category.id}
              to={`/category/${category.slug}`}
              className="group relative overflow-hidden border border-white/5 bg-[#111] hover:border-red-600/40 transition-all duration-500"
            >
              <div className="aspect-[3/4] overflow-hidden bg-[#1a1a1a] relative">
                <img
                  src={category.heroImage}
                  alt={category.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
                {/* Fallback gradient when image doesn't load */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] -z-10"></div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="font-mono text-[9px] text-red-500/70 tracking-[0.3em] uppercase mb-2">
                  {category.subcategories.length} SUBCATEGORIES
                </div>
                <h3 className="font-heading text-xl font-black uppercase text-white mb-2">{category.name}</h3>
                <div className="flex items-center gap-2 text-gray-500 group-hover:text-red-500 transition-colors">
                  <span className="font-mono text-[10px] uppercase tracking-widest">Explore</span>
                  <ArrowRight className="w-3 h-3 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}