import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowRight, ChevronRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { getCategoryBySlug, getSubcategoryProducts, categories } from '@/data/categories';
import type { Product, CategoryData } from '@/data/categories';

// --- Product Card ---
function ProductCard({ product, categorySlug }: { product: Product; categorySlug: string }) {
  return (
    <Link
      to={`/category/${categorySlug}/product/${product.id}`}
      className="group relative overflow-hidden border border-white/5 bg-[#141414] hover:border-red-600/40 transition-all duration-500 block"
    >
      <div className="aspect-[3/4] overflow-hidden bg-[#1a1a1a]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).style.display = 'none';
          }}
        />
      </div>
      <div className="p-4 border-t border-white/5">
        <h4 className="font-heading text-sm font-bold uppercase tracking-wide text-gray-100 mb-1">{product.name}</h4>
        <p className="font-mono text-xs text-gray-500 mb-2 line-clamp-1">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="font-heading text-lg font-black text-white">{product.price}</span>
          <span className="text-[10px] font-mono uppercase tracking-widest text-red-500 group-hover:text-red-400 transition-colors">
            VIEW →
          </span>
        </div>
      </div>
    </Link>
  );
}

// --- Subcategory Nav ---
function SubcategoryNav({ category }: { category: CategoryData }) {
  return (
    <div className="flex flex-wrap gap-3">
      {category.subcategories.map((sub) => (
        <Link
          key={sub.id}
          to={`/category/${category.slug}/${sub.slug}`}
          className="group flex items-center gap-2 px-5 py-3 border border-white/10 bg-[#0f0f0f] hover:border-red-600/50 hover:bg-red-600/5 transition-all duration-300"
        >
          <span className="font-heading text-xs font-bold uppercase tracking-wider text-gray-300 group-hover:text-white transition-colors">
            {sub.name}
          </span>
          <ChevronRight className="w-3 h-3 text-gray-600 group-hover:text-red-500 transition-colors" />
        </Link>
      ))}
    </div>
  );
}

// --- Main Category Page ---
export default function CategoryPage() {
  const { categorySlug, subcategorySlug } = useParams<{ categorySlug: string; subcategorySlug?: string }>();
  const category = getCategoryBySlug(categorySlug || '');

  if (!category) {
    return (
      <div className="w-full min-h-screen bg-[#0a0a0a] text-white">
        <Header />
        <div className="pt-40 pb-20 text-center">
          <h1 className="font-heading text-4xl font-black uppercase text-white mb-4">CATEGORY NOT FOUND</h1>
          <p className="text-gray-500 font-mono text-sm mb-8">The requested category does not exist.</p>
          <Link to="/store" className="inline-flex items-center gap-2 bg-red-600 text-white font-heading text-xs font-bold uppercase px-6 py-3 hover:bg-red-700 transition-colors tracking-wider">
            BACK TO STORE <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  // Determine which products to show
  const displayProducts = subcategorySlug
    ? getSubcategoryProducts(category.slug, subcategorySlug)
    : category.products;

  // Find active subcategory name
  const activeSubcategory = subcategorySlug
    ? category.subcategories.find((s) => s.slug === subcategorySlug)
    : null;

  return (
    <div className="w-full min-h-screen bg-[#0a0a0a] text-white selection:bg-red-600 selection:text-white">
      <Header />

      {/* ===== HERO MEDIA ===== */}
      <section className="relative w-full h-[70vh] md:h-[80vh] overflow-hidden bg-[#111]">
        <img
          src={category.heroImage}
          alt={category.name}
          className="absolute inset-0 w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).style.display = 'none';
          }}
        />
        {/* Dark cinematic overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-[#0a0a0a]"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/50"></div>

        {/* Grain texture overlay */}
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'200\' height=\'200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence baseFrequency=\'0.9\' numOctaves=\'4\' type=\'fractalNoise\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")' }}></div>

        {/* Category label */}
        <div className="absolute bottom-12 left-0 right-0 px-4 md:px-12">
          <div className="max-w-[120rem] mx-auto">
            <div className="font-mono text-[10px] text-red-500/80 tracking-[0.4em] uppercase mb-3">
              {activeSubcategory ? `${category.name} // ${activeSubcategory.name}` : `Noble Anarchy // ${category.name}`}
            </div>
            <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl font-black uppercase tracking-tighter text-white leading-[0.85]">
              {category.name}
            </h1>
          </div>
        </div>
      </section>

      {/* ===== CONTENT BODY ===== */}
      <section className="w-full px-4 md:px-12 py-16 md:py-24">
        <div className="max-w-[80rem] mx-auto">

          {/* 1. Headline */}
          <div className="mb-12 md:mb-16">
            <div className="w-16 h-[2px] bg-red-600 mb-6"></div>
            <h2 className="font-heading text-3xl md:text-5xl lg:text-6xl font-black uppercase tracking-tight text-white leading-[1.1]">
              {category.content.headline}
            </h2>
          </div>

          {/* 2. The Short of It */}
          <div className="mb-12 md:mb-16 max-w-3xl">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-red-500 mb-4">THE SHORT OF IT</h3>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              {category.content.shortOfIt}
            </p>
          </div>

          {/* 3. The Why */}
          <div className="mb-12 md:mb-16 max-w-3xl pl-0 md:pl-8 border-l-2 border-white/10">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-red-500 mb-4">THE WHY</h3>
            <p className="text-base md:text-lg text-gray-400 leading-relaxed italic">
              {category.content.theWhy}
            </p>
          </div>

          {/* 4. What's Inside */}
          <div className="mb-12 md:mb-16">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-red-500 mb-6">WHAT&apos;S INSIDE</h3>
            <ul className="space-y-3">
              {category.content.whatsInside.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="mt-1.5 w-2 h-2 bg-red-600 flex-shrink-0"></span>
                  <span className="text-base text-gray-300">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* 5. CTA */}
          <div className="mb-16 md:mb-24">
            <Link
              to={`/category/${category.slug}`}
              className="inline-flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-heading text-sm font-bold uppercase px-8 py-4 tracking-wider transition-all duration-300 hover:gap-4"
            >
              {category.content.cta}
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          {/* Subcategory Navigation */}
          <div className="mb-16">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-gray-500 mb-5">BROWSE BY</h3>
            <SubcategoryNav category={category} />
          </div>
        </div>
      </section>

      {/* ===== PRODUCT GRID ===== */}
      <section className="w-full px-4 md:px-12 pb-24 md:pb-32">
        <div className="max-w-[120rem] mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-heading text-2xl md:text-3xl font-black uppercase tracking-tight text-white">
              {activeSubcategory ? activeSubcategory.name : 'ALL PRODUCTS'}
            </h3>
            <span className="font-mono text-[10px] text-gray-600 tracking-widest uppercase">
              {displayProducts.length} ITEMS
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {displayProducts.map((product) => (
              <ProductCard key={product.id} product={product} categorySlug={category.slug} />
            ))}
          </div>
        </div>
      </section>

      {/* ===== ALL CATEGORIES NAV ===== */}
      <section className="w-full px-4 md:px-12 pb-24 border-t border-white/5 pt-16">
        <div className="max-w-[120rem] mx-auto">
          <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-gray-500 mb-8">ALL CATEGORIES</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/category/${cat.slug}`}
                className={`px-4 py-3 border text-center font-heading text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                  cat.slug === category.slug
                    ? 'border-red-600 bg-red-600/10 text-red-500'
                    : 'border-white/10 text-gray-400 hover:border-white/30 hover:text-white'
                }`}
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}