import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Minus, Plus, ChevronRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { getProductById, getCategoryBySlug } from '@/data/categories';

export default function ProductDetail() {
  const { categorySlug, productId } = useParams<{ categorySlug: string; productId: string }>();
  const category = getCategoryBySlug(categorySlug || '');
  const product = getProductById(categorySlug || '', productId || '');

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  if (!product || !category) {
    return (
      <div className="w-full min-h-screen bg-[#0a0a0a] text-white">
        <Header />
        <div className="pt-40 pb-20 text-center">
          <h1 className="font-heading text-4xl font-black uppercase text-white mb-4">PRODUCT NOT FOUND</h1>
          <p className="text-gray-500 font-mono text-sm mb-8">This item has been removed from the arsenal.</p>
          <Link to="/store" className="inline-flex items-center gap-2 bg-red-600 text-white font-heading text-xs font-bold uppercase px-6 py-3 hover:bg-red-700 transition-colors tracking-wider">
            BACK TO STORE <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const images = product.images && product.images.length > 0 ? product.images : [product.image];
  const sizes = product.sizes || ['S', 'M', 'L', 'XL'];
  const colors = product.colors || [{ name: 'Blackout', hex: '#0a0a0a' }];
  const details = product.details || [];

  const handleAddToCart = () => {
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  return (
    <div className="w-full min-h-screen bg-[#0a0a0a] text-white selection:bg-red-600 selection:text-white">
      <Header />

      {/* Breadcrumb */}
      <div className="w-full px-4 md:px-12 pt-24 pb-4">
        <div className="max-w-[120rem] mx-auto">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-gray-500">
            <Link to="/store" className="hover:text-white transition-colors">Store</Link>
            <ChevronRight className="w-3 h-3" />
            <Link to={`/category/${category.slug}`} className="hover:text-white transition-colors">{category.name}</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-gray-300">{product.name}</span>
          </nav>
        </div>
      </div>

      {/* Back link */}
      <div className="w-full px-4 md:px-12 pb-6">
        <div className="max-w-[120rem] mx-auto">
          <Link
            to={`/category/${category.slug}`}
            className="inline-flex items-center gap-2 font-mono text-xs text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to {category.name}
          </Link>
        </div>
      </div>

      {/* Product Content */}
      <section className="w-full px-4 md:px-12 pb-24">
        <div className="max-w-[120rem] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">

            {/* ===== IMAGE GALLERY ===== */}
            <div className="space-y-4">
              {/* Main Image */}
              <div className="relative aspect-[3/4] overflow-hidden bg-[#111] border border-white/5">
                <img
                  src={images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.opacity = '0.3';
                  }}
                />
                {/* Grain overlay */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'200\' height=\'200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence baseFrequency=\'0.9\' numOctaves=\'4\' type=\'fractalNoise\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")' }}></div>
              </div>

              {/* Thumbnail Strip */}
              {images.length > 1 && (
                <div className="flex gap-3">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(idx)}
                      className={`relative w-20 h-24 overflow-hidden border-2 transition-all duration-300 ${
                        selectedImage === idx
                          ? 'border-red-600 opacity-100'
                          : 'border-white/10 opacity-50 hover:opacity-80 hover:border-white/30'
                      }`}
                    >
                      <img
                        src={img}
                        alt={`${product.name} view ${idx + 1}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.opacity = '0.3';
                        }}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* ===== PRODUCT INFO ===== */}
            <div className="flex flex-col">
              {/* Category tag */}
              <div className="font-mono text-[10px] uppercase tracking-[0.4em] text-red-500/80 mb-3">
                {category.name} COLLECTION
              </div>

              {/* Product Name */}
              <h1 className="font-heading text-3xl md:text-4xl lg:text-5xl font-black uppercase tracking-tight text-white leading-[1.1] mb-4">
                {product.name}
              </h1>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-6">
                <span className="font-heading text-3xl md:text-4xl font-black text-white">{product.price}</span>
                <span className="font-mono text-[10px] text-gray-500 uppercase tracking-widest">USD</span>
              </div>

              {/* Divider */}
              <div className="w-full h-[1px] bg-white/10 mb-6"></div>

              {/* Description */}
              <p className="text-base text-gray-300 leading-relaxed mb-8">
                {product.description}
              </p>

              {/* Color Selector */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-gray-400">Color</span>
                  <span className="font-mono text-[11px] text-gray-500">{colors[selectedColor].name}</span>
                </div>
                <div className="flex gap-3">
                  {colors.map((color, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedColor(idx)}
                      className={`relative w-10 h-10 rounded-full border-2 transition-all duration-300 ${
                        selectedColor === idx
                          ? 'border-red-600 scale-110'
                          : 'border-white/20 hover:border-white/50'
                      }`}
                      title={color.name}
                    >
                      <span
                        className="absolute inset-1 rounded-full"
                        style={{ backgroundColor: color.hex }}
                      ></span>
                      {selectedColor === idx && (
                        <span className="absolute inset-0 rounded-full ring-2 ring-red-600/30 ring-offset-2 ring-offset-[#0a0a0a]"></span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-gray-400">Size</span>
                  {selectedSize && (
                    <span className="font-mono text-[11px] text-gray-500">Selected: {selectedSize}</span>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[3rem] px-4 py-3 border font-heading text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                        selectedSize === size
                          ? 'border-red-600 bg-red-600/10 text-white'
                          : 'border-white/10 text-gray-400 hover:border-white/30 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div className="mb-8">
                <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-gray-400 mb-3 block">Quantity</span>
                <div className="inline-flex items-center border border-white/10">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-14 h-12 flex items-center justify-center font-heading text-sm font-bold text-white border-x border-white/10">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                disabled={!selectedSize}
                className={`w-full flex items-center justify-center gap-3 py-4 px-8 font-heading text-sm font-bold uppercase tracking-wider transition-all duration-300 ${
                  addedToCart
                    ? 'bg-green-600 text-white'
                    : selectedSize
                      ? 'bg-red-600 hover:bg-red-700 text-white hover:gap-4'
                      : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                {addedToCart ? 'ADDED TO CART ✓' : selectedSize ? 'ADD TO CART' : 'SELECT A SIZE'}
              </button>

              {!selectedSize && (
                <p className="mt-2 font-mono text-[10px] text-red-500/70 uppercase tracking-widest text-center">
                  Please select a size to continue
                </p>
              )}

              {/* Product Details */}
              {details.length > 0 && (
                <div className="mt-10 pt-8 border-t border-white/10">
                  <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-red-500 mb-5">PRODUCT DETAILS</h3>
                  <ul className="space-y-3">
                    {details.map((detail, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <span className="mt-1.5 w-1.5 h-1.5 bg-red-600 flex-shrink-0"></span>
                        <span className="text-sm text-gray-400">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Shipping info */}
              <div className="mt-8 p-4 border border-white/5 bg-[#111]">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                    <span className="font-mono text-[10px] text-gray-400 uppercase tracking-widest">Free shipping on orders $100+</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                    <span className="font-mono text-[10px] text-gray-400 uppercase tracking-widest">30-day returns, no questions asked</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                    <span className="font-mono text-[10px] text-gray-400 uppercase tracking-widest">Ships within 2-3 business days</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== RELATED PRODUCTS ===== */}
      <section className="w-full px-4 md:px-12 pb-24 border-t border-white/5 pt-16">
        <div className="max-w-[120rem] mx-auto">
          <h3 className="font-heading text-2xl font-black uppercase tracking-tight text-white mb-8">
            MORE FROM {category.name}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {category.products
              .filter((p) => p.id !== product.id)
              .slice(0, 4)
              .map((relatedProduct) => (
                <Link
                  key={relatedProduct.id}
                  to={`/category/${category.slug}/product/${relatedProduct.id}`}
                  className="group relative overflow-hidden border border-white/5 bg-[#141414] hover:border-red-600/40 transition-all duration-500"
                >
                  <div className="aspect-[3/4] overflow-hidden bg-[#1a1a1a]">
                    <img
                      src={relatedProduct.image}
                      alt={relatedProduct.name}
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                      loading="lazy"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>
                  <div className="p-3 border-t border-white/5">
                    <h4 className="font-heading text-xs font-bold uppercase tracking-wide text-gray-100 mb-1 truncate">{relatedProduct.name}</h4>
                    <span className="font-heading text-sm font-black text-white">{relatedProduct.price}</span>
                  </div>
                </Link>
              ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}