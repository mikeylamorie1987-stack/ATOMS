import React, { useRef, useEffect, useState, useMemo } from 'react';
import { motion, useScroll, useTransform, useMotionValueEvent } from 'framer-motion';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// --- CALLSIGN CODE ANIMATION ---
const CallsignText = ({ text, className }: { text: string; className?: string }) => {
  const [displayText, setDisplayText] = useState('');
  const [isResolved, setIsResolved] = useState(false);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*';
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isResolved) {
          let iteration = 0;
          const maxIterations = text.length * 3;
          const interval = setInterval(() => {
            setDisplayText(
              text
                .split('')
                .map((char, index) => {
                  if (char === ' ') return ' ';
                  if (index < iteration / 3) return text[index];
                  return chars[Math.floor(Math.random() * chars.length)];
                })
                .join('')
            );
            iteration++;
            if (iteration >= maxIterations) {
              clearInterval(interval);
              setDisplayText(text);
              setIsResolved(true);
            }
          }, 40);
          return () => clearInterval(interval);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, [text, isResolved]);

  return (
    <div ref={ref} className={className}>
      <span className="font-mono tracking-[0.2em]">{displayText || text.replace(/./g, '█')}</span>
    </div>
  );
};

// --- HUD ELEMENT ---
const HudElement = ({ children, className, speed = 1 }: { children: React.ReactNode; className?: string; speed?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 100 * speed]);

  return (
    <motion.div ref={ref} style={{ y }} className={`absolute pointer-events-none select-none ${className}`}>
      {children}
    </motion.div>
  );
};

// --- TACTICAL BENTO CARD ---
const TacticalCard = ({ name, sector, image, price }: { name: string; sector: string; image: string; price: string }) => {
  return (
    <div className="group relative border border-white/10 bg-[#1a1a1a] hover:border-red-500/60 hover:shadow-[0_0_20px_rgba(255,0,0,0.1)] transition-all duration-300 hover:-translate-y-1 overflow-hidden">
      <div className="absolute top-2 left-2 z-10">
        <span className="font-mono text-[10px] text-amber-500/70 tracking-widest">{sector}</span>
      </div>
      <div className="aspect-[3/4] overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-4 border-t border-white/5">
        <h3 className="font-heading text-sm font-bold uppercase text-white tracking-wider">{name}</h3>
        <p className="font-mono text-xs text-red-500 mt-1">{price}</p>
      </div>
    </div>
  );
};

// --- RANGE TABLE ROW ---
const RangeTableRow = ({ name, weight, fabric, rating }: { name: string; weight: string; fabric: string; rating: string }) => {
  return (
    <tr className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
      <td className="py-4 px-4 font-mono text-sm text-white uppercase tracking-wider group-hover:text-red-400 transition-colors">{name}</td>
      <td className="py-4 px-4 font-mono text-xs text-silver-metallic text-center">{weight}</td>
      <td className="py-4 px-4 font-mono text-xs text-silver-metallic text-center">{fabric}</td>
      <td className="py-4 px-4 font-mono text-xs text-right">
        <span className="inline-block px-3 py-1 border border-amber-500/30 text-amber-500 text-[10px] uppercase tracking-widest">{rating}</span>
      </td>
    </tr>
  );
};

// --- MAIN PAGE ---
export default function TacticalDropPage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const camoRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress: heroProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const { scrollYProgress: camoProgress } = useScroll({
    target: camoRef,
    offset: ["start end", "end start"]
  });

  // Armory door animation - faster response
  const leftDoorX = useTransform(heroProgress, [0, 0.25], ['0%', '-105%']);
  const rightDoorX = useTransform(heroProgress, [0, 0.25], ['0%', '105%']);

  // Target reticle animation - faster lock-on
  const reticleScale = useTransform(heroProgress, [0.05, 0.35], [2.5, 1]);
  const imageBlur = useTransform(heroProgress, [0.05, 0.35], [8, 0]);
  const [blurValue, setBlurValue] = useState(8);

  useMotionValueEvent(imageBlur, 'change', (latest) => {
    setBlurValue(latest);
  });

  // Camo wipe - faster reveal
  const camoX = useTransform(camoProgress, [0, 0.45], ['-100%', '0%']);

  const products = useMemo(() => [
    { name: 'GHOST PROTOCOL TEE', sector: 'SECTOR A1', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$68.00' },
    { name: 'BLACKOUT OPS HOODIE', sector: 'SECTOR A2', image: 'https://static.wixstatic.com/media/13b202_b86d995151a0442283368f4c1169c3b2~mv2.png', price: '$128.00' },
    { name: 'DOOMED OPS CARGO', sector: 'SECTOR B1', image: 'https://static.wixstatic.com/media/13b202_82226a01e9444fb6b80c9085347503d8~mv2.png', price: '$148.00' },
    { name: 'WARPATH FLANNEL', sector: 'SECTOR B2', image: 'https://static.wixstatic.com/media/13b202_ae80660c61ac444d939b05b7a8eb2e16~mv2.png', price: '$98.00' },
    { name: 'IRON DOCTRINE VEST', sector: 'SECTOR B3', image: 'https://static.wixstatic.com/media/13b202_6315f6bb18c14af487160a4d0f98fb91~mv2.png', price: '$178.00' },
    { name: 'NIGHT RAID BOMBER', sector: 'SECTOR C1', image: 'https://static.wixstatic.com/media/13b202_545aa9a2e0254888aedf55fb826dec0c~mv2.png', price: '$198.00' },
    { name: 'SCORCHED EARTH TEE', sector: 'SECTOR C2', image: 'https://static.wixstatic.com/media/13b202_9efb1e64d97f4b57a189c9bfea43788b~mv2.png', price: '$58.00' },
    { name: 'BREACH & CLEAR PANT', sector: 'SECTOR D1', image: 'https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png', price: '$138.00' },
  ], []);

  const rangeData = useMemo(() => [
    { name: 'URBAN OPS TEE', weight: '14oz', fabric: '100% Cotton', rating: 'HEAVYWEIGHT' },
    { name: 'GHOST PROTOCOL HOODIE', weight: '18oz', fabric: 'Cotton/Poly Blend', rating: 'TACTICAL' },
    { name: 'DOOMED OPS CARGO', weight: '16oz', fabric: 'Ripstop Canvas', rating: 'FIELD GRADE' },
    { name: 'NIGHT RAID BOMBER', weight: '22oz', fabric: 'Nylon/Cotton Shell', rating: 'ARMORED' },
    { name: 'IRON DOCTRINE VEST', weight: '12oz', fabric: 'Waxed Cotton', rating: 'RECON' },
    { name: 'SCORCHED EARTH FLANNEL', weight: '10oz', fabric: '100% Cotton Twill', rating: 'PATROL' },
    { name: 'BREACH & CLEAR PANT', weight: '15oz', fabric: 'Stretch Ripstop', rating: 'ASSAULT' },
    { name: 'WARPATH HENLEY', weight: '8oz', fabric: 'Slub Cotton Jersey', rating: 'STEALTH' },
  ], []);

  return (
    <div className="w-full bg-[#0a0a0a] text-white overflow-clip selection:bg-red-600 selection:text-white">
      <Header />

      {/* ===== ARMORY DOOR HERO ===== */}
      <section ref={heroRef} className="relative w-full h-[150vh]">
        <div className="sticky top-0 w-full h-screen overflow-hidden">
          {/* Background metal texture */}
          <div className="absolute inset-0 bg-[#111] bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cfilter%20id%3D%22n%22%3E%3CfeTurbulence%20baseFrequency%3D%220.8%22%20numOctaves%3D%224%22%20type%3D%22fractalNoise%22%2F%3E%3C%2Ffilter%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20filter%3D%22url(%23n)%22%20opacity%3D%220.04%22%2F%3E%3C%2Fsvg%3E')]"></div>

          {/* Collection image behind doors */}
          <div className="absolute inset-0 flex items-center justify-center">
            <img
              src="https://static.wixstatic.com/media/13b202_477e0f015f23417a854cb45a2da50535~mv2.png"
              alt="Collection reveal"
              className="w-full h-full object-cover"
              style={{ filter: `blur(${blurValue}px)` }}
            />
          </div>

          {/* Target reticle */}
          <motion.div
            style={{ scale: reticleScale }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
          >
            <svg viewBox="0 0 400 400" className="w-[60vmin] h-[60vmin] text-red-500/40">
              <circle cx="200" cy="200" r="180" fill="none" stroke="currentColor" strokeWidth="0.5" />
              <circle cx="200" cy="200" r="120" fill="none" stroke="currentColor" strokeWidth="0.3" strokeDasharray="4 8" />
              <circle cx="200" cy="200" r="60" fill="none" stroke="currentColor" strokeWidth="0.5" />
              <line x1="200" y1="0" x2="200" y2="140" stroke="currentColor" strokeWidth="0.5" />
              <line x1="200" y1="260" x2="200" y2="400" stroke="currentColor" strokeWidth="0.5" />
              <line x1="0" y1="200" x2="140" y2="200" stroke="currentColor" strokeWidth="0.5" />
              <line x1="260" y1="200" x2="400" y2="200" stroke="currentColor" strokeWidth="0.5" />
              {/* Tick marks */}
              {[...Array(36)].map((_, i) => {
                const angle = (i * 10 * Math.PI) / 180;
                const r1 = 175;
                const r2 = i % 3 === 0 ? 165 : 170;
                return (
                  <line
                    key={i}
                    x1={200 + r1 * Math.cos(angle)}
                    y1={200 + r1 * Math.sin(angle)}
                    x2={200 + r2 * Math.cos(angle)}
                    y2={200 + r2 * Math.sin(angle)}
                    stroke="currentColor"
                    strokeWidth="0.4"
                  />
                );
              })}
            </svg>
          </motion.div>

          {/* Armory doors */}
          <motion.div
            style={{ x: leftDoorX }}
            className="absolute top-0 left-0 w-1/2 h-full z-30 bg-[#0d0d0d] border-r border-white/5"
          >
            {/* Door texture */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#111] to-[#0a0a0a]"></div>
            <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-black/40 to-transparent"></div>
            {/* Rivets */}
            <div className="absolute right-6 top-1/4 w-3 h-3 rounded-full bg-[#222] border border-white/5 shadow-inner"></div>
            <div className="absolute right-6 top-3/4 w-3 h-3 rounded-full bg-[#222] border border-white/5 shadow-inner"></div>
            {/* Handle */}
            <div className="absolute right-4 top-1/2 -translate-y-1/2 w-2 h-24 bg-[#1a1a1a] border border-white/10 rounded-sm"></div>
          </motion.div>

          <motion.div
            style={{ x: rightDoorX }}
            className="absolute top-0 right-0 w-1/2 h-full z-30 bg-[#0d0d0d] border-l border-white/5"
          >
            <div className="absolute inset-0 bg-gradient-to-l from-[#111] to-[#0a0a0a]"></div>
            <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black/40 to-transparent"></div>
            <div className="absolute left-6 top-1/4 w-3 h-3 rounded-full bg-[#222] border border-white/5 shadow-inner"></div>
            <div className="absolute left-6 top-3/4 w-3 h-3 rounded-full bg-[#222] border border-white/5 shadow-inner"></div>
            <div className="absolute left-4 top-1/2 -translate-y-1/2 w-2 h-24 bg-[#1a1a1a] border border-white/10 rounded-sm"></div>
          </motion.div>

          {/* HUD Overlay elements */}
          <HudElement className="top-20 left-8 z-40" speed={0.3}>
            <div className="font-mono text-[10px] text-green-500/30 space-y-1">
              <div>LAT 34.0522° N</div>
              <div>LNG 118.2437° W</div>
              <div>ALT 0071m</div>
            </div>
          </HudElement>

          <HudElement className="top-32 right-8 z-40" speed={0.5}>
            <div className="font-mono text-[10px] text-amber-500/25 text-right space-y-1">
              <div>RNG: 0000m</div>
              <div>WND: 3.2 kts NNW</div>
              <div>TEMP: 72°F</div>
            </div>
          </HudElement>

          <HudElement className="bottom-32 left-8 z-40" speed={0.2}>
            <div className="flex items-center gap-2">
              <div className="w-16 h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="w-3/4 h-full bg-green-500/40 rounded-full"></div>
              </div>
              <span className="font-mono text-[9px] text-green-500/30">PWR 74%</span>
            </div>
          </HudElement>

          <HudElement className="bottom-24 right-8 z-40" speed={0.4}>
            <div className="font-mono text-[9px] text-red-500/25 text-right">
              <div>SYS: ACTIVE</div>
              <div>MODE: ACQUIRE</div>
            </div>
          </HudElement>

          {/* Range finder marks - corners */}
          <div className="absolute top-16 left-16 w-12 h-12 border-t border-l border-white/10 z-40 pointer-events-none"></div>
          <div className="absolute top-16 right-16 w-12 h-12 border-t border-r border-white/10 z-40 pointer-events-none"></div>
          <div className="absolute bottom-16 left-16 w-12 h-12 border-b border-l border-white/10 z-40 pointer-events-none"></div>
          <div className="absolute bottom-16 right-16 w-12 h-12 border-b border-r border-white/10 z-40 pointer-events-none"></div>

          {/* Callsign text - centered on screen */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 text-center">
            <div className="font-mono text-[10px] text-amber-500/60 tracking-[0.5em] mb-4">INCOMING TRANSMISSION</div>
            <CallsignText
              text="DROP 07: DOOMED OPS"
              className="text-3xl md:text-5xl font-bold text-white/90"
            />
            <p className="font-mono text-xs text-silver-metallic/50 mt-4 tracking-[0.3em]">NOBLE ANARCHY COLLECTIVE // TACTICAL DIVISION</p>
            <p className="font-mono text-[10px] text-red-500/40 mt-2 tracking-[0.2em]">▼ SCROLL TO BREACH ▼</p>
          </div>
        </div>
      </section>

      {/* ===== TACTICAL BENTO GRID ===== */}
      <section className="relative w-full py-24 bg-[#0d0d0d]">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          {/* Section header */}
          <div className="flex items-center justify-between mb-12 border-b border-white/5 pb-6">
            <div>
              <span className="font-mono text-[10px] text-amber-500/70 tracking-[0.4em] block mb-2">MOLLE PANEL // INVENTORY</span>
              <h2 className="font-heading text-4xl md:text-5xl font-black uppercase tracking-tight text-white">TACTICAL GRID</h2>
            </div>
            <div className="hidden md:block font-mono text-[10px] text-white/20 text-right">
              <div>ITEMS: {products.length}</div>
              <div>STATUS: IN STOCK</div>
            </div>
          </div>

          {/* Bento Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-[1px] bg-white/5">
            {/* Large card */}
            <div className="col-span-2 row-span-2">
              <TacticalCard {...products[0]} />
            </div>
            {/* Regular cards */}
            {products.slice(1, 5).map((product, i) => (
              <div key={i}>
                <TacticalCard {...product} />
              </div>
            ))}
            {/* Wide card */}
            <div className="col-span-2">
              <TacticalCard {...products[5]} />
            </div>
            {products.slice(6).map((product, i) => (
              <div key={i}>
                <TacticalCard {...product} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CAMO WIPE REVEAL ===== */}
      <section ref={camoRef} className="relative w-full py-32 overflow-hidden">
        {/* Base charcoal background */}
        <div className="absolute inset-0 bg-[#1a1a1a]"></div>

        {/* Camo pattern that wipes in */}
        <motion.div
          style={{ x: camoX }}
          className="absolute inset-0"
        >
          <div className="w-full h-full opacity-20" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3Cpattern id='camo' patternUnits='userSpaceOnUse' width='200' height='200'%3E%3Crect width='200' height='200' fill='%23222'/%3E%3Cellipse cx='50' cy='30' rx='60' ry='25' fill='%23333'/%3E%3Cellipse cx='150' cy='80' rx='50' ry='35' fill='%23292929'/%3E%3Cellipse cx='80' cy='140' rx='70' ry='30' fill='%23333'/%3E%3Cellipse cx='170' cy='170' rx='40' ry='20' fill='%23292929'/%3E%3Cellipse cx='30' cy='90' rx='35' ry='45' fill='%23303030'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width='200' height='200' fill='url(%23camo)'/%3E%3C/svg%3E")`,
            backgroundSize: '200px 200px'
          }}></div>
        </motion.div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-16">
            <span className="font-mono text-[10px] text-green-500/60 tracking-[0.4em]">CAMOUFLAGE SERIES</span>
            <h2 className="font-heading text-5xl md:text-7xl font-black uppercase text-white mt-4">BLEND IN.<br />STAND OUT.</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.slice(0, 3).map((product, i) => (
              <div key={i} className="relative group">
                <div className="aspect-[3/4] overflow-hidden border border-white/5">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="mt-4">
                  <h3 className="font-mono text-sm text-white uppercase tracking-wider">{product.name}</h3>
                  <p className="font-mono text-xs text-red-500 mt-1">{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== RANGE TABLE LAYOUT ===== */}
      <section className="relative w-full py-24 bg-[#0a0a0a]">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          {/* Header */}
          <div className="border-b border-white/10 pb-6 mb-8">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="font-mono text-[10px] text-red-500/70 tracking-[0.4em]">BALLISTICS DATA // CLASSIFIED</span>
            </div>
            <h2 className="font-heading text-4xl md:text-5xl font-black uppercase text-white tracking-tight">RANGE TABLE</h2>
            <p className="font-mono text-xs text-white/30 mt-2">TECHNICAL SPECIFICATIONS // ALL UNITS METRIC EQUIVALENT</p>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="py-3 px-4 text-left font-mono text-[10px] text-amber-500/70 uppercase tracking-[0.3em]">Designation</th>
                  <th className="py-3 px-4 text-center font-mono text-[10px] text-amber-500/70 uppercase tracking-[0.3em]">Weight</th>
                  <th className="py-3 px-4 text-center font-mono text-[10px] text-amber-500/70 uppercase tracking-[0.3em]">Composition</th>
                  <th className="py-3 px-4 text-right font-mono text-[10px] text-amber-500/70 uppercase tracking-[0.3em]">Classification</th>
                </tr>
              </thead>
              <tbody>
                {rangeData.map((row, i) => (
                  <RangeTableRow key={i} {...row} />
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer note */}
          <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
            <span className="font-mono text-[9px] text-white/20 tracking-widest">DOC REF: NAC-2024-07-SPEC</span>
            <span className="font-mono text-[9px] text-white/20 tracking-widest">DISTRIBUTION: UNLIMITED</span>
          </div>
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="w-full py-24 bg-[#0d0d0d] border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-heading text-5xl md:text-7xl font-black uppercase text-white tracking-tight mb-6">
            GEAR UP
          </h2>
          <p className="font-mono text-sm text-silver-metallic/60 tracking-widest mb-10 uppercase">
            Mission briefing complete // Deploy to store
          </p>
          <Link
            to="/store"
            className="inline-flex items-center gap-3 bg-red-600 text-white font-heading text-lg font-bold uppercase px-12 py-5 hover:bg-red-700 transition-colors tracking-wider"
          >
            ENTER THE ARMORY
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}