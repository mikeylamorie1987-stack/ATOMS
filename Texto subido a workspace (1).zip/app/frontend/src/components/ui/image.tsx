import React from 'react';

interface ImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt?: string;
  className?: string;
  originWidth?: number;
  originHeight?: number;
  focalPointX?: number;
  focalPointY?: number;
}

export const Image: React.FC<ImageProps> = ({
  src,
  alt = '',
  className = '',
  originWidth,
  originHeight,
  focalPointX,
  focalPointY,
  ...props
}) => {
  const style: React.CSSProperties = {};
  if (focalPointX !== undefined && focalPointY !== undefined) {
    style.objectPosition = `${focalPointX}% ${focalPointY}%`;
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      style={style}
      loading="lazy"
      {...props}
    />
  );
};