import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-background/95 backdrop-blur-md border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <div className="max-w-[120rem] mx-auto px-4 md:px-8 flex items-center justify-between h-20">
        {/* Logo */}
        <Link to="/" className="font-heading text-2xl font-black uppercase tracking-tighter text-foreground hover:text-primary transition-colors">
          NAC<span className="text-primary">.</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <Link to="/store" className="font-paragraph text-sm uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors">
            Store
          </Link>
          <Link to="/tactical" className="font-paragraph text-sm uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors">
            Tactical Drop
          </Link>
          <Link to="/store" className="font-paragraph text-sm uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors">
            About
          </Link>
          <Link to="/store" className="bg-primary text-white font-heading font-bold uppercase text-xs px-6 py-3 hover:bg-primary/90 transition-colors tracking-wider">
            Shop Now
          </Link>
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-foreground"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background/98 backdrop-blur-md border-t border-white/5">
          <nav className="flex flex-col items-center gap-6 py-8">
            <Link to="/store" className="font-paragraph text-lg uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
              Store
            </Link>
            <Link to="/store" className="font-paragraph text-lg uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
              Collections
            </Link>
            <Link to="/store" className="font-paragraph text-lg uppercase tracking-widest text-silver-metallic hover:text-primary transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
              About
            </Link>
            <Link to="/store" className="bg-primary text-white font-heading font-bold uppercase px-8 py-3 hover:bg-primary/90 transition-colors tracking-wider" onClick={() => setIsMobileMenuOpen(false)}>
              Shop Now
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;