import React, { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Image } from '@/components/ui/image';
import { ArrowRight, ChevronRight } from 'lucide-react';

interface CollectionShowcaseProps {
  collectionId: string;
  collectionName: string;
  collectionDescription: string;
  features: string[];
  mediaImage1: string;
  mediaImage2: string;
  primaryCTA: string;
  secondaryCTA?: string;
  debug?: boolean;
}

const Reveal = ({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(element);
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${className || ''} ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

const CollectionShowcase: React.FC<CollectionShowcaseProps> = ({
  collectionId,
  collectionName,
  collectionDescription,
  features,
  mediaImage1,
  mediaImage2,
  primaryCTA,
  secondaryCTA,
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const y1 = useTransform(scrollYProgress, [0, 1], ["5%", "-5%"]);
  const y2 = useTransform(scrollYProgress, [0, 1], ["-3%", "3%"]);

  return (
    <section ref={ref} className="relative w-full py-24 md:py-32 bg-background border-t border-white/5">
      <div className="max-w-[120rem] mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Images */}
          <div className="relative h-[500px] md:h-[600px]">
            <motion.div
              style={{ y: y1 }}
              className="absolute top-0 left-0 w-[65%] h-[75%] overflow-hidden border border-white/10 shadow-2xl"
            >
              <Image
                src={mediaImage1}
                alt={`${collectionName} - Image 1`}
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"></div>
            </motion.div>
            <motion.div
              style={{ y: y2 }}
              className="absolute bottom-0 right-0 w-[55%] h-[65%] overflow-hidden border border-white/10 shadow-2xl"
            >
              <Image
                src={mediaImage2}
                alt={`${collectionName} - Image 2`}
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"></div>
            </motion.div>
          </div>

          {/* Content */}
          <div className="flex flex-col justify-center">
            <Reveal>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-[2px] bg-primary"></div>
                <span className="text-xs uppercase tracking-[0.3em] text-silver-metallic font-paragraph">Collection</span>
              </div>
            </Reveal>

            <Reveal delay={100}>
              <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl font-black text-foreground uppercase tracking-tight mb-6">
                {collectionName}
              </h2>
            </Reveal>

            <Reveal delay={200}>
              <p className="font-paragraph text-silver-metallic text-lg leading-relaxed mb-8 max-w-lg">
                {collectionDescription}
              </p>
            </Reveal>

            <Reveal delay={300}>
              <ul className="space-y-3 mb-10">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3 text-silver-metallic/80 font-paragraph">
                    <ChevronRight className="w-4 h-4 text-primary flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={400}>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/store"
                  className="bg-primary text-white font-heading font-bold uppercase px-8 py-4 hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 text-sm tracking-wider"
                >
                  {primaryCTA} <ArrowRight className="w-4 h-4" />
                </Link>
                {secondaryCTA && (
                  <Link
                    to="/store"
                    className="border border-white/30 text-white font-heading font-bold uppercase px-8 py-4 hover:bg-white hover:text-black transition-colors flex items-center justify-center text-sm tracking-wider"
                  >
                    {secondaryCTA}
                  </Link>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CollectionShowcase;