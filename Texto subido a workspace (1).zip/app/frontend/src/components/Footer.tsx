import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#050505] border-t border-white/5 py-16">
      <div className="max-w-[120rem] mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link to="/" className="font-heading text-3xl font-black uppercase tracking-tighter text-foreground">
              NOBLE ANARCHY<span className="text-primary">.</span>
            </Link>
            <p className="font-paragraph text-silver-metallic/70 mt-4 max-w-md leading-relaxed">
              Built for the unbroken. Every stitch is a statement. Every design is a declaration. We don't follow trends — we set the standard.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center text-silver-metallic hover:text-primary hover:border-primary transition-colors text-xs font-heading font-bold">
                IG
              </a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center text-silver-metallic hover:text-primary hover:border-primary transition-colors text-xs font-heading font-bold">
                X
              </a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center text-silver-metallic hover:text-primary hover:border-primary transition-colors text-xs font-heading font-bold">
                FB
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-heading text-sm font-bold uppercase tracking-widest text-foreground mb-6">Shop</h4>
            <ul className="space-y-3">
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">All Collections</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">New Arrivals</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">Best Sellers</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">Sale</Link></li>
            </ul>
          </div>

          {/* Info */}
          <div>
            <h4 className="font-heading text-sm font-bold uppercase tracking-widest text-foreground mb-6">Info</h4>
            <ul className="space-y-3">
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">About Us</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">Shipping</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">Returns</Link></li>
              <li><Link to="/store" className="font-paragraph text-silver-metallic/70 hover:text-primary transition-colors text-sm">Contact</Link></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-paragraph text-silver-metallic/50 text-xs uppercase tracking-widest">
            © 2024 Noble Anarchy Collective. All rights reserved.
          </p>
          <p className="font-paragraph text-silver-metallic/30 text-xs uppercase tracking-widest">
            Built with conviction // Made in America
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;