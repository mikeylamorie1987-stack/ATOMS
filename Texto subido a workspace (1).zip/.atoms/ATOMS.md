# Project Context

## Project Overview
Noble Anarchy Collective - A streetwear brand website with a dark, raw, patriotic aesthetic. Features immersive parallax scrolling, animated text effects, and 8 collection showcases.

## Key Decisions
| Date | Decision | By | Rationale |
|------|----------|-----|-----------|
| 2026-05-30 | Dark theme with red primary (#FF0000) | Alex | Matches brand's raw, defiant identity |
| 2026-05-30 | Framer Motion for animations | Alex | Smooth parallax and reveal animations |
| 2026-05-30 | Google Fonts (Oswald, Inter, Cinzel) | Alex | Heading/body/accent font hierarchy |

## Constraints
- Color Palette: Background #0d0d0d, Primary Red #FF0000, Secondary Bronze #B87333, Silver Metallic #A8A9AD
- Typography: Oswald (headings), Inter (body), Cinzel (accent/decorative)
- Layout: Full-width sections, max-w-120rem containers, parallax imagery
- Visual Elements: Grain overlay, glitch text effects, grayscale-to-color hover transitions