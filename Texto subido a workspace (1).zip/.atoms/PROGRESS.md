# Requirements & Progress

## Requirements Overview
Build a streetwear brand website for "Noble Anarchy Collective" with a dark, edgy aesthetic featuring parallax effects, animated text, and multiple collection showcases.

## User Stories
- As a visitor, I can see an immersive hero section with animated brand name and CTA
- As a visitor, I can scroll through the brand manifesto with sticky layout and value cards
- As a visitor, I can browse 8 different collection showcases with parallax imagery
- As a visitor, I can navigate to the store page to see all collections in a grid

## Task Breakdown
- [x] Set up dark theme CSS with custom colors (red primary, silver metallic, dark background)
- [x] Configure Tailwind with custom fonts (Oswald, Inter, Cinzel) and brand colors
- [x] Create Image utility component
- [x] Create CollectionShowcase reusable component with parallax images
- [x] Build Homepage with hero, ticker, manifesto, editorial split, quote, 8 collections, and CTA
- [x] Create Header component with scroll-aware styling and mobile menu
- [x] Create Footer component with brand info and links
- [x] Create Store page with collection grid and routing
- [x] Create product data layer with 18 products across 8 collections
- [x] Create Collection page (/store/:collectionId) with product grid
- [x] Create Product Detail page (/store/:collectionId/:productId) with image gallery, size selector, quantity, Add to Cart

## Progress Log
- 2026-05-30: Project initialized with frontend template, all 8 tasks completed, lint and build passing
- 2026-06-01: Added Tactical Drop page (/tactical) with armory door hero, target lock-on reticle, callsign code animation, HUD overlay, tactical bento grid, camo wipe reveal, and range table layout. Lint and build passing.
- 2026-05-31: Added product detail pages with image gallery, size selector, price, Add to Cart. Collection pages and routing added. Lint and build passing.
- 2026-06-01: Applied custom "Stencil Style New" font to the main hero header "Noble Anarchy Collective" and the red scrolling ticker banner. Font loaded via @font-face from /fonts/StencilStyleNew.ttf.
- 2026-06-01: Added Theme Customizer panel (floating gear button, bottom-right) with live controls for hero font, ticker font, primary color, background darkness, text case, and letter spacing. Settings persist in localStorage.
- 2026-06-01: Enhanced Theme Customizer with 16 additional custom fonts, font size sliders for hero/ticker, and 5 one-click presets (Classic Red, Gold Luxury, Neon Cyber, Stealth Dark, Anarchy Raw).
- 2026-06-01: Updated entire color scheme — Background #121212, Surface #18181B, Card #1F1F23, Elevated #26262B, Primary text #F3F4F6, Secondary text #D1D5DB, Muted #9CA3AF, Border #34343A, CTA Red #C00000, Hover Red #D90429, Dark Gold #A37500, Copper #B46A3C, Silver #B8BDC7, Ash White #E8E8E5.
- 2026-06-01: Replaced all Star SVG icons with uploaded star.png image — in ticker marquee, mission card 3, and Theme Customizer header. Removed unused lucide imports. Lint and build passing.
- 2026-06-01: Refined CategoryPage and Store page — improved image fallbacks, cleaner layout, proper gradient overlays. Lint and build passing.
- 2026-06-01: Added Product Detail page (/category/:categorySlug/product/:productId) with image gallery, thumbnails, color swatches, size selector, quantity controls, Add to Cart button, product details list, shipping info, and related products grid. All product cards now link to detail pages. Lint and build passing.