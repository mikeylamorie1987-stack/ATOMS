# Architecture Design

## System Overview
Single-page React application with client-side routing. Pure frontend with no backend requirements. Features heavy use of scroll-based animations and parallax effects.

## Tech Stack
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS + shadcn/ui
- Framer Motion (animations)
- React Router DOM (routing)

## Module Design
| Module | Responsibility | Key Files |
|--------|---------------|-----------|
| Pages | Route-level page components | src/pages/Index.tsx, src/pages/Store.tsx |
| Layout | Header/Footer navigation | src/components/Header.tsx, src/components/Footer.tsx |
| Showcase | Collection display component | src/components/CollectionShowcase.tsx |
| UI | Reusable UI primitives | src/components/ui/image.tsx |

## Tech Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|
| Animation library | Framer Motion | Required for parallax scroll effects and smooth reveals |
| CSS approach | Tailwind + custom CSS vars | Dark theme with brand-specific color tokens |
| Font loading | Google Fonts CDN | Fast loading for Oswald, Inter, Cinzel |

## File Tree Plan
```
src/
├── App.tsx
├── index.css
├── pages/
│   ├── Index.tsx (homepage)
│   └── Store.tsx (store page)
├── components/
│   ├── Header.tsx
│   ├── Footer.tsx
│   ├── CollectionShowcase.tsx
│   └── ui/
│       └── image.tsx
```

## Implementation Guide
- Homepage uses Reveal component for scroll-triggered animations
- ParallaxImage uses Framer Motion useScroll/useTransform for depth effect
- Marquee ticker uses infinite CSS animation
- CollectionShowcase is reusable with configurable props for each collection