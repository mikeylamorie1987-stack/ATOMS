/**
 * Blog prerender script
 * This script is used to prerender blog pages for SEO
 */

export async function prerender() {
  // Return empty array if no pages to prerender
  return [];
}
