/**
 * Get blog routes for prerendering
 * Returns an array of routes to be prerendered
 */
export function getBlogRoutes() {
  // Return empty array if no blog routes are configured
  // Add your blog routes here as needed
  return [];
}
