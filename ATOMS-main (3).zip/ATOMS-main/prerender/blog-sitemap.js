/**
 * Get sitemap lastmod date for blog
 * Returns the last modification date for the sitemap
 */
export function getSitemapLastmod() {
  // Return current date or specify a custom date
  return new Date().toISOString().split('T')[0];
}
