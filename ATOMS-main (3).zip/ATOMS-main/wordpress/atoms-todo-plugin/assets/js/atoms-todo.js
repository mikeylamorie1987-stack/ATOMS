document.addEventListener('DOMContentLoaded', function() {
    const todoApp = new AtomsTodoApp();
    todoApp.init();
});

class AtomsTodoApp {
    constructor() {
        this.todoInput = document.getElementById('atoms-todo-input');
        this.addBtn = document.getElementById('atoms-todo-add-btn');
        this.todoList = document.getElementById('atoms-todo-list');
        this.clearBtn = document.getElementById('atoms-todo-clear-btn');
        this.filterBtns = document.querySelectorAll('.atoms-todo-filter-btn');
        this.countSpan = document.getElementById('atoms-todo-count');
        
        this.todos = [];
        this.currentFilter = 'all';
        this.storageKey = 'atomsTodoList';
    }

    init() {
        this.loadTodos();
        this.attachEventListeners();
        this.renderTodos();
    }

    attachEventListeners() {
        this.addBtn.addEventListener('click', () => this.addTodo());
        this.todoInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addTodo();
        });

        this.filterBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterBtns.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.currentFilter = e.target.dataset.filter;
                this.renderTodos();
            });
        });

        this.clearBtn.addEventListener('click', () => this.clearCompleted());
    }

    addTodo() {
        const text = this.todoInput.value.trim();
        if (text === '') return;

        const todo = {
            id: Date.now(),
            text: text,
            completed: false
        };

        this.todos.push(todo);
        this.saveTodos();
        this.renderTodos();
        this.todoInput.value = '';
    }

    deleteTodo(id) {
        this.todos = this.todos.filter(todo => todo.id !== id);
        this.saveTodos();
        this.renderTodos();
    }

    toggleTodo(id) {
        const todo = this.todos.find(todo => todo.id === id);
        if (todo) {
            todo.completed = !todo.completed;
            this.saveTodos();
            this.renderTodos();
        }
    }

    clearCompleted() {
        this.todos = this.todos.filter(todo => !todo.completed);
        this.saveTodos();
        this.renderTodos();
    }

    filterTodos() {
        switch (this.currentFilter) {
            case 'active':
                return this.todos.filter(todo => !todo.completed);
            case 'completed':
                return this.todos.filter(todo => todo.completed);
            default:
                return this.todos;
        }
    }

    renderTodos() {
        this.todoList.innerHTML = '';
        const filteredTodos = this.filterTodos();

        filteredTodos.forEach(todo => {
            const li = document.createElement('li');
            li.className = `atoms-todo-item ${todo.completed ? 'completed' : ''}`;

            li.innerHTML = `
                <input type="checkbox" class="atoms-todo-checkbox" ${todo.completed ? 'checked' : ''}>
                <p class="atoms-todo-text">${this.escapeHtml(todo.text)}</p>
                <button class="atoms-todo-delete">×</button>
            `;

            const checkbox = li.querySelector('.atoms-todo-checkbox');
            checkbox.addEventListener('change', () => this.toggleTodo(todo.id));

            const deleteBtn = li.querySelector('.atoms-todo-delete');
            deleteBtn.addEventListener('click', () => this.deleteTodo(todo.id));

            this.todoList.appendChild(li);
        });

        this.updateCount();
    }

    updateCount() {
        const activeTodos = this.todos.filter(todo => !todo.completed).length;
        this.countSpan.textContent = activeTodos;
    }

    saveTodos() {
        localStorage.setItem(this.storageKey, JSON.stringify(this.todos));
    }

    loadTodos() {
        const stored = localStorage.getItem(this.storageKey);
        this.todos = stored ? JSON.parse(stored) : [];
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}
