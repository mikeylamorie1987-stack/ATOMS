<?php
/**
 * Plugin Name: Atoms To-Do List
 * Plugin URI: https://github.com/Nobleart3613/Atoms
 * Description: A simple to-do list plugin with local storage for WordPress
 * Version: 1.0.0
 * Author: Noble Anarchy Collective
 * License: GPL v2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ATOMS_TODO_VERSION', '1.0.0' );
define( 'ATOMS_TODO_DIR', plugin_dir_path( __FILE__ ) );
define( 'ATOMS_TODO_URL', plugin_dir_url( __FILE__ ) );

function atoms_todo_enqueue_assets() {
    wp_enqueue_style(
        'atoms-todo-style',
        ATOMS_TODO_URL . 'assets/css/atoms-todo.css',
        array(),
        ATOMS_TODO_VERSION
    );

    wp_enqueue_script(
        'atoms-todo-script',
        ATOMS_TODO_URL . 'assets/js/atoms-todo.js',
        array(),
        ATOMS_TODO_VERSION,
        true
    );
}
add_action( 'wp_enqueue_scripts', 'atoms_todo_enqueue_assets' );

function atoms_todo_shortcode() {
    ob_start();
    ?>
    <div id="atoms-todo-app" class="atoms-todo-container">
        <div class="atoms-todo-header">
            <h2>My To-Do List</h2>
        </div>
        <div class="atoms-todo-input-section">
            <input type="text" id="atoms-todo-input" class="atoms-todo-input" placeholder="Add a new task...">
            <button id="atoms-todo-add-btn" class="atoms-todo-btn atoms-todo-btn-primary">Add Task</button>
        </div>
        <div class="atoms-todo-filters">
            <button class="atoms-todo-filter-btn active" data-filter="all">All</button>
            <button class="atoms-todo-filter-btn" data-filter="active">Active</button>
            <button class="atoms-todo-filter-btn" data-filter="completed">Completed</button>
        </div>
        <ul id="atoms-todo-list" class="atoms-todo-list"></ul>
        <div class="atoms-todo-footer">
            <span class="atoms-todo-count"><span id="atoms-todo-count">0</span> tasks</span>
            <button id="atoms-todo-clear-btn" class="atoms-todo-btn atoms-todo-btn-secondary">Clear Completed</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'atoms_todo', 'atoms_todo_shortcode' );
