<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function atoms_child_theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'atoms-child-style', get_stylesheet_uri(), array( 'parent-style' ) );
}
add_action( 'wp_enqueue_scripts', 'atoms_child_theme_enqueue_styles' );

function atoms_child_theme_setup() {
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'atoms_child_theme_setup' );
