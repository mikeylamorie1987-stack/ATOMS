# Atoms WordPress Child Theme

This is a WordPress child theme based on the **Atoms** design system with a modern dark theme featuring red and orange accent colors.

## Features

- **Dark Theme**: Modern dark background (#0D0D0D) with light text (#F5F5F5)
- **Primary Colors**: 
  - Red (#FF0000) - Primary accent
  - Orange (#CC6633) - Secondary accent
- **Typography**:
  - Oswald font for headings (bold, uppercase)
  - Inter font for body text (clean, readable)
  - Cinzel font for elegant accents
- **WooCommerce Ready**: Fully styled for e-commerce
- **Responsive Design**: Mobile-first approach
- **Elementor Compatible**: Works seamlessly with Elementor page builder

## Installation

### Method 1: Manual Installation
1. Extract the `atoms-child-theme` folder to `/wp-content/themes/`
2. Go to WordPress admin → Appearance → Themes
3. Activate "Atoms Child Theme"

### Method 2: From GitHub
1. Clone the repository:
   ```bash
   cd /wp-content/themes/
   git clone https://github.com/Nobleart3613/Atoms.git atoms-child-theme
   ```
2. Activate in WordPress admin

## Setup Instructions

### 1. Install Parent Theme
This child theme requires a parent theme. We recommend:
- **TwentyTwentyFour** (WordPress default)
- **GeneratePress**
- **Neve**

### 2. Install Required Plugins
- **Elementor Pro** (recommended for advanced features)
- **WooCommerce** (for e-commerce)

### 3. Configure Elementor Colors
1. Go to Elementor → Settings → Global Colors
2. Add custom colors matching the Atoms palette:
   - Primary: `#FF0000`
   - Secondary: `#CC6633`
   - Background: `#0D0D0D`
   - Foreground: `#F5F5F5`

### 4. Import Custom CSS
1. In Elementor, go to Settings → Custom CSS
2. Copy the contents of `elementor-atoms-custom.css`
3. Paste into the Custom CSS field

## Color Variables

```css
--atoms-primary: #FF0000
--atoms-secondary: #CC6633
--atoms-background: #0D0D0D
--atoms-foreground: #F5F5F5
--atoms-card: #131313
--atoms-muted: #1F1F1F
--atoms-border: #262626
--atoms-accent: #262626
```

## Usage

### Using Atoms Classes in Elementor

Add these classes to Elementor elements:

**Background Colors:**
- `.atoms-bg-primary` - Red background
- `.atoms-bg-secondary` - Orange background
- `.atoms-bg-card` - Card background

**Text Colors:**
- `.atoms-text-primary` - Red text
- `.atoms-text-secondary` - Orange text
- `.atoms-text-muted` - Muted text

**Utilities:**
- `.atoms-uppercase` - Uppercase text with letter spacing
- `.atoms-border-primary` - Red border
- `.atoms-rounded` - Rounded corners
- `.atoms-spacing-lg` - Large spacing
- `.atoms-spacing-md` - Medium spacing
- `.atoms-spacing-sm` - Small spacing

### Typography Classes

```html
<!-- Oswald heading style -->
<h1>Bold Headlines</h1>

<!-- Inter paragraph style -->
<p>Regular body text</p>

<!-- Cinzel accent -->
<span class="font-cinzel">Elegant text</span>
```

## WooCommerce Styling

The theme automatically styles WooCommerce elements:
- Product cards with hover effects
- Red primary buttons
- Price displays in red
- Star ratings in red

## Customization

### Changing Primary Color

Edit `style.css` and change:
```css
--atoms-primary: #FF0000; /* Change this value */
```

### Adding Custom Fonts

Edit `functions.php`:
```php
function atoms_custom_fonts() {
    wp_enqueue_style( 'atoms-fonts', 
        'https://fonts.googleapis.com/css2?family=YourFont:wght@400;700&display=swap' 
    );
}
add_action( 'wp_enqueue_scripts', 'atoms_custom_fonts' );
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Troubleshooting

### Colors not showing?
1. Clear WordPress cache
2. Hard refresh browser (Ctrl+F5)
3. Check Elementor CSS is loaded

### Fonts not loading?
1. Verify Google Fonts API is accessible
2. Check browser console for errors
3. Ensure CDN is not blocked

### WooCommerce styling issues?
1. Deactivate other WooCommerce plugins
2. Regenerate WooCommerce pages
3. Check CSS specificity in browser inspector

## Support

For issues and questions, visit:
- GitHub: https://github.com/Nobleart3613/Atoms
- Email: thenobleartistllc@gmail.com

## License

This child theme is licensed under GPL v2 or later.

## Credits

- Design System: Atoms
- Parent Theme: TwentyTwentyFour (or your chosen theme)
- Typography: Google Fonts
